# Login — UIKit / Storyboard / Simple Segue

Beginner iOS project inspired by the “Lab—Login” exercise visible in your photo.

## What it demonstrates
- A Login screen with username and password text fields
- A Login button connected to an `IBAction`
- A Storyboard **Show** segue to a second Welcome screen
- `prepare(for:sender:)` passing the username to the destination view controller
- Auto Layout and safe-area layout in the storyboard

This is a recreated learning project based on the visible description, not Apple's original project files. The login action is a demonstration only; it does not authenticate credentials.

## Open
1. Extract the ZIP on a Mac.
2. Open `Login.xcodeproj` in Xcode.
3. Choose an iPhone simulator and press Run.

Target: iOS 15+, Swift 5.
