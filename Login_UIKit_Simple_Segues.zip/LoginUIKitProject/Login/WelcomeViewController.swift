import UIKit

class WelcomeViewController: UIViewController {
    @IBOutlet weak var welcomeLabel: UILabel!
    var username: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        welcomeLabel.text = {
            let name = username?.isEmpty == false ? username! : "there"
            return "Welcome, \\(name)!"
        }()
    }
}
