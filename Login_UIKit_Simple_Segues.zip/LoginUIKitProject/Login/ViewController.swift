import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var usernameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Login"
        usernameTextField.autocorrectionType = .no
        usernameTextField.autocapitalizationType = .none
        passwordTextField.isSecureTextEntry = true
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showWelcome",
           let destination = segue.destination as? WelcomeViewController {
            destination.username = usernameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }

    @IBAction func loginButtonTapped(_ sender: UIButton) {
        // This is a learning exercise: the button demonstrates a Storyboard segue.
        // No real authentication or password checking is performed.
        performSegue(withIdentifier: "showWelcome", sender: self)
    }
}
