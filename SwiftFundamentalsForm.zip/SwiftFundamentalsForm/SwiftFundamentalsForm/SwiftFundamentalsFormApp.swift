import SwiftUI

@main
struct SwiftFundamentalsFormApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
