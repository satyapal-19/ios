import SwiftUI

struct ContentView: View {
    @State private var fullName = ""
    @State private var email = ""
    @State private var selectedCourse = "Computer Science"
    @State private var wantsUpdates = true
    @State private var submitted = false

    private let courses = [
        "Computer Science",
        "Information Technology",
        "Mechanical Engineering",
        "Electrical Engineering"
    ]

    var body: some View {
        NavigationStack {
            Form {
                Section("Personal Information") {
                    TextField("Full name", text: $fullName)
                        .textContentType(.name)
                        .textInputAutocapitalization(.words)

                    TextField("Email address", text: $email)
                        .keyboardType(.emailAddress)
                        .textContentType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }

                Section("Course Details") {
                    Picker("Course", selection: $selectedCourse) {
                        ForEach(courses, id: \.self) { course in
                            Text(course).tag(course)
                        }
                    }

                    Toggle("Receive course updates", isOn: $wantsUpdates)
                }

                Section {
                    Button("Submit Form") {
                        submitted = true
                    }
                    .frame(maxWidth: .infinity)
                    .disabled(fullName.trimmingCharacters(in: .whitespaces).isEmpty ||
                              email.trimmingCharacters(in: .whitespaces).isEmpty)
                } footer: {
                    Text("Enter your name and email address to enable submission.")
                }
            }
            .navigationTitle("Student Form")
            .alert("Form Submitted", isPresented: $submitted) {
                Button("OK", role: .cancel) { }
            } message: {
                Text("Thanks, \\(fullName)! Course: \\(selectedCourse). Updates: \\(wantsUpdates ? "On" : "Off").")
            }
        }
    }
}

#Preview {
    ContentView()
}
