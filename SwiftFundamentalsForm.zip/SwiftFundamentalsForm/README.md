# Swift Fundamentals — Simple Form Screen

A small SwiftUI Xcode project demonstrating a form screen with:
- Name and email text fields
- Course picker
- Updates toggle
- Submit button and confirmation alert
- Navigation title and native Form sections

## Open in Xcode
1. Unzip `SwiftFundamentalsForm.zip`.
2. Open `SwiftFundamentalsForm.xcodeproj` in Xcode on a Mac.
3. Select an iPhone simulator.
4. Press Run (▶).

## Requirements
- Xcode 15 or newer
- iOS 17 or newer deployment target

This is an original beginner-friendly example inspired by common Swift fundamentals exercises, not an official Apple textbook project.
